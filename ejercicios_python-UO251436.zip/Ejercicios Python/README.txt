Se adjuntan todos los ejercicios hechos en clase para la parte de Python de la asignatura
(excepto la práctica final de python, que va aparte).